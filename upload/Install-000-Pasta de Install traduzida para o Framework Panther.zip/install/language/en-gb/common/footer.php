<?php
// Text
$_['text_project']       = 'Project Homepage';
$_['text_documentation'] = 'Documentation';
$_['text_support']       = 'Support Forums';
