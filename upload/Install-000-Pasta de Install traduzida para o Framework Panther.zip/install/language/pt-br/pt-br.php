<?php
// Text
$_['text_name']       = 'Português-Brasil';
$_['text_loading']    = 'Carregando...';

// Button
$_['button_continue'] = 'Continuar';
$_['button_back']     = 'Voltar';

// Error
$_['error_exception'] = 'Código de erro(%s): %s em %s na linha %s';