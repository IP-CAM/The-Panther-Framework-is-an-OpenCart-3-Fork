<?php
// Text
$_['text_footer']  = '<a href="https://www.bitstore.com.br">Bitstore</a> &copy; 2009-' . date('Y') . ' Todos os direitos reservados.';
$_['text_version'] = 'Versão %s (Brasil %s)';