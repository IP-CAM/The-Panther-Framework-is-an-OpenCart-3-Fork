<?php
// Heading
$_['heading_title'] = 'Painel de controle';

// Error
$_['error_install'] = 'Atenção: A pasta install não foi excluída! Para manter a segurança de sua loja, exclua a pasta install.';